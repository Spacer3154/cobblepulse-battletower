package fr.cobblepulse.battletower.gui;

import fr.cobblepulse.battletower.core.ItemBuilder;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

/** Liste paginee generique (45 entrees par page + barre de navigation). */
public final class Paged {
    public record Entry(class_1799 item, Gui.Handler handler) {}

    private Paged() {}

    public static void open(class_3222 player, String title, List<Entry> entries, int page, Consumer<class_3222> back) {
        open(player, title, entries, page, back, null);
    }

    public static void open(class_3222 player, String title, List<Entry> entries, int page, Consumer<class_3222> back,
                            Consumer<Gui> decorate) {
        int per = 45;
        int pages = Math.max(1, (entries.size() + per - 1) / per);
        int pg = Math.max(0, Math.min(page, pages - 1));
        Gui gui = new Gui(6, title + (pages > 1 ? " &8(" + (pg + 1) + "/" + pages + ")" : ""));
        for (int i = 0; i < per; i++) {
            int idx = pg * per + i;
            if (idx >= entries.size()) break;
            Entry e = entries.get(idx);
            gui.set(i, e.item(), e.handler());
        }
        for (int i = 45; i < 54; i++) gui.set(i, Gui.pane());
        if (pg > 0) {
            gui.button(45, ItemBuilder.of(class_1802.field_8107).name("&ePage precedente").build(),
                    p -> open(p, title, entries, pg - 1, back, decorate));
        }
        if (pg < pages - 1) {
            gui.button(53, ItemBuilder.of(class_1802.field_8107).name("&ePage suivante").build(),
                    p -> open(p, title, entries, pg + 1, back, decorate));
        }
        if (back != null) {
            gui.button(49, ItemBuilder.of(class_1802.field_8691).name("&cRetour").build(), back);
        }
        if (decorate != null) decorate.accept(gui);
        gui.open(player);
    }
}
