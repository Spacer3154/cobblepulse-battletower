package fr.cobblepulse.battletower.gui;

import fr.cobblepulse.battletower.core.ItemBuilder;
import fr.cobblepulse.battletower.core.Scheduler;
import fr.cobblepulse.battletower.core.TextUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1277;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/**
 * Menu coffre pilote par le serveur. Aucun item ne peut etre deplace, retire ou jete :
 * chaque clic est intercepte et transforme en action.
 */
public class Gui {
    public record Click(class_1713 type, int button) {
        public boolean right() {
            return type == class_1713.field_7790 && button == 1;
        }

        public boolean left() {
            return type == class_1713.field_7790 && button == 0;
        }

        public boolean shift() {
            return type == class_1713.field_7794;
        }
    }

    @FunctionalInterface
    public interface Handler {
        void click(class_3222 player, Click click);
    }

    final int rows;
    final class_2561 title;
    final class_1277 container;
    final Map<Integer, Handler> handlers = new HashMap<>();
    Consumer<class_3222> onClose;

    public Gui(int rows, String legacyTitle) {
        this(rows, TextUtil.legacy(legacyTitle));
    }

    public Gui(int rows, class_2561 title) {
        this.rows = Math.max(1, Math.min(6, rows));
        this.title = title;
        this.container = new class_1277(this.rows * 9);
    }

    public int size() {
        return rows * 9;
    }

    public Gui set(int slot, class_1799 item) {
        return set(slot, item, null);
    }

    public Gui set(int slot, class_1799 item, Handler handler) {
        if (slot < 0 || slot >= size()) return this;
        container.method_5447(slot, item == null ? class_1799.field_8037 : item);
        if (handler != null) handlers.put(slot, handler);
        else handlers.remove(slot);
        return this;
    }

    /** Action simple (tout type de clic). */
    public Gui button(int slot, class_1799 item, Consumer<class_3222> action) {
        return set(slot, item, (p, c) -> action.accept(p));
    }

    public Gui fill(class_1799 filler) {
        for (int i = 0; i < size(); i++) {
            if (container.method_5438(i).method_7960()) container.method_5447(i, filler.method_7972());
        }
        return this;
    }

    public Gui border() {
        class_1799 pane = pane();
        for (int i = 0; i < size(); i++) {
            int r = i / 9;
            int c = i % 9;
            if ((r == 0 || r == rows - 1 || c == 0 || c == 8) && container.method_5438(i).method_7960()) container.method_5447(i, pane.method_7972());
        }
        return this;
    }

    public Gui onClose(Consumer<class_3222> c) {
        this.onClose = c;
        return this;
    }

    public static class_1799 pane() {
        return ItemBuilder.of(class_1802.field_8871).name(" ").hideExtra().build();
    }

    public void open(class_3222 player) {
        player.method_17355(new class_747((id, inv, p) -> new LockedMenu(id, inv, this), title));
    }

    /** Ouvre au tick suivant (a utiliser depuis un clic pour eviter la reentrance). */
    public void openLater(class_3222 player) {
        Scheduler.next(() -> {
            if (!player.method_14239()) open(player);
        });
    }

    void handleClick(class_3222 player, int slot, Click click) {
        Handler h = handlers.get(slot);
        if (h != null) Scheduler.next(() -> {
            if (!player.method_14239()) h.click(player, click);
        });
    }
}
