package fr.cobblepulse.battletower.integration;

import fr.cobblepulse.battletower.Battletower;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3222;

/** Facade sans dependance dure vers LuckPerms (les classes LP ne sont touchees que si le mod est present). */
public final class LuckPermsBridge {
    private static final boolean PRESENT = FabricLoader.getInstance().isModLoaded("luckperms");
    private static boolean warned;

    private LuckPermsBridge() {}

    public static boolean present() {
        return PRESENT;
    }

    /** @return true/false si le noeud est defini (y compris via joker), null sinon ou si LuckPerms est absent. */
    public static Boolean check(class_3222 p, String node) {
        if (!PRESENT || p == null) return null;
        try {
            return LuckPermsHook.check(p, node);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                Battletower.LOG.warn("[Battletower] API LuckPerms indisponible : {}", t.toString());
            }
            return null;
        }
    }
}
