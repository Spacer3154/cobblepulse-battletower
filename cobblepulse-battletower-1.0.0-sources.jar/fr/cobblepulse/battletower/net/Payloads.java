package fr.cobblepulse.battletower.net;

import fr.cobblepulse.battletower.Battletower;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Paquets reseau de l'editeur de PNJ (le mod est requis cote client pour l'editeur et la galerie de skins). */
public final class Payloads {
    private static final class_9139<ByteBuf, String> BIG_STRING = class_9135.method_56364(1 << 20);

    private Payloads() {}

    private static <T extends class_8710> class_8710.class_9154<T> makeType(String path) {
        return new class_8710.class_9154<>(class_2960.method_60655(Battletower.MOD_ID, path));
    }

    /** Serveur -> client : ouvre l'editeur (kind = floor/boss, id = etage ou identifiant du boss). */
    public record OpenEditor(String kind, String id, String trainerJson, String metaJson) implements class_8710 {
        public static final class_9154<OpenEditor> TYPE = makeType("open_editor");
        public static final class_9139<ByteBuf, OpenEditor> CODEC = class_9139.method_56905(
                class_9135.field_48554, OpenEditor::kind, class_9135.field_48554, OpenEditor::id,
                BIG_STRING, OpenEditor::trainerJson, BIG_STRING, OpenEditor::metaJson, OpenEditor::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Client -> serveur : enregistre la fiche du dresseur. */
    public record SaveTrainer(String kind, String id, String trainerJson, boolean force) implements class_8710 {
        public static final class_9154<SaveTrainer> TYPE = makeType("save_trainer");
        public static final class_9139<ByteBuf, SaveTrainer> CODEC = class_9139.method_56905(
                class_9135.field_48554, SaveTrainer::kind, class_9135.field_48554, SaveTrainer::id,
                BIG_STRING, SaveTrainer::trainerJson, class_9135.field_48547, SaveTrainer::force, SaveTrainer::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Serveur -> client : resultat de l'enregistrement (erreurs de validation eventuelles). */
    public record EditorResult(boolean ok, String message, String errorsJson) implements class_8710 {
        public static final class_9154<EditorResult> TYPE = makeType("editor_result");
        public static final class_9139<ByteBuf, EditorResult> CODEC = class_9139.method_56436(
                class_9135.field_48547, EditorResult::ok, class_9135.field_48554, EditorResult::message,
                BIG_STRING, EditorResult::errorsJson, EditorResult::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Client -> serveur : demande les octets d'un skin (dossier serveur ou compte Mojang) pour l'apercu 3D. */
    public record SkinRequest(String ref) implements class_8710 {
        public static final class_9154<SkinRequest> TYPE = makeType("skin_request");
        public static final class_9139<ByteBuf, SkinRequest> CODEC = class_9139.method_56434(
                class_9135.field_48554, SkinRequest::ref, SkinRequest::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Serveur -> client : skin PNG (vide si introuvable). */
    public record SkinData(String ref, boolean slim, byte[] png) implements class_8710 {
        public static final class_9154<SkinData> TYPE = makeType("skin_data");
        public static final class_9139<ByteBuf, SkinData> CODEC = class_9139.method_56436(
                class_9135.field_48554, SkinData::ref, class_9135.field_48547, SkinData::slim,
                class_9135.field_48987, SkinData::png, SkinData::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
}
