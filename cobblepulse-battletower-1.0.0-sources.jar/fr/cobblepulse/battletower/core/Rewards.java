package fr.cobblepulse.battletower.core;

import fr.cobblepulse.battletower.Battletower;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.List;

/** Distribution d'items ("modid:item quantite") et execution de commandes console (%player%). */
public final class Rewards {
    private Rewards() {}

    public static void giveItems(class_3222 p, List<String> specs) {
        if (p == null || specs == null) return;
        for (String spec : specs) giveItem(p, spec);
    }

    public static boolean giveItem(class_3222 p, String spec) {
        if (spec == null || spec.isBlank()) return false;
        String[] parts = spec.trim().split("\\s+");
        class_1792 item = ItemBuilder.item(parts[0], class_1802.field_8162);
        if (item == class_1802.field_8162) {
            Battletower.LOG.warn("[Battletower] Item inconnu dans une recompense : {}", parts[0]);
            return false;
        }
        int count = 1;
        if (parts.length > 1) {
            try {
                count = Math.max(1, Integer.parseInt(parts[1]));
            } catch (NumberFormatException ignored) {
            }
        }
        while (count > 0) {
            int n = Math.min(count, item.method_7882());
            class_1799 stack = new class_1799(item, n);
            if (!p.method_31548().method_7394(stack)) p.method_7328(stack, false);
            count -= n;
        }
        return true;
    }

    public static void runCommands(class_3222 p, String name, List<String> commands) {
        MinecraftServer s = Battletower.server();
        if (s == null || commands == null) return;
        String player = p != null ? p.method_7334().getName() : name;
        for (String c : commands) {
            if (c == null || c.isBlank()) continue;
            String cmd = c.replace("%player%", player == null ? "" : player).trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            try {
                s.method_3734().method_44252(s.method_3739().method_9217(), cmd);
            } catch (Throwable t) {
                Battletower.LOG.warn("[Battletower] Commande de recompense en echec '{}' : {}", cmd, t.toString());
            }
        }
    }
}
