package fr.cobblepulse.battletower.core;

import fr.cobblepulse.battletower.Battletower;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import net.minecraft.class_1262;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_7225;

/** Serialisation d'inventaires (NBT compresse en Base64). A appeler sur le thread principal. */
public final class ItemSerial {
    private ItemSerial() {}

    private static class_7225.class_7874 registries() {
        return Battletower.server().method_30611();
    }

    public static String encode(List<class_1799> items) {
        try {
            class_2371<class_1799> list = class_2371.method_10213(items.size(), class_1799.field_8037);
            for (int i = 0; i < items.size(); i++) list.set(i, items.get(i) == null ? class_1799.field_8037 : items.get(i));
            class_2487 tag = new class_2487();
            tag.method_10569("Size", items.size());
            class_1262.method_5426(tag, list, registries());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            class_2507.method_10634(tag, out);
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            Battletower.LOG.error("[Battletower] Serialisation d'items impossible", e);
            return "";
        }
    }

    public static List<class_1799> decode(String data) {
        List<class_1799> out = new ArrayList<>();
        if (data == null || data.isEmpty()) return out;
        try {
            class_2487 tag = class_2507.method_10629(new ByteArrayInputStream(Base64.getDecoder().decode(data)), class_2505.method_53898());
            int size = tag.method_10550("Size");
            class_2371<class_1799> list = class_2371.method_10213(size, class_1799.field_8037);
            class_1262.method_5429(tag, list, registries());
            out.addAll(list);
        } catch (Exception e) {
            Battletower.LOG.error("[Battletower] Deserialisation d'items impossible", e);
        }
        return out;
    }

    public static String encode(class_1277 c) {
        List<class_1799> l = new ArrayList<>();
        for (int i = 0; i < c.method_5439(); i++) l.add(c.method_5438(i));
        return encode(l);
    }

    public static void decodeInto(String data, class_1277 c) {
        List<class_1799> l = decode(data);
        for (int i = 0; i < c.method_5439(); i++) {
            c.method_5447(i, i < l.size() ? l.get(i) : class_1799.field_8037);
        }
    }

    public static List<class_1799> nonEmpty(List<class_1799> in) {
        List<class_1799> out = new ArrayList<>();
        for (class_1799 s : in) if (s != null && !s.method_7960()) out.add(s);
        return out;
    }
}
