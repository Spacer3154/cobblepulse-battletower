package fr.cobblepulse.battletower.core;

import fr.cobblepulse.battletower.Battletower;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Recherche de joueurs connectes (inclut les joueurs factices de l'auto-test). */
public final class Players {
    private static final Map<UUID, class_3222> TEST_PLAYERS = new HashMap<>();

    private Players() {}

    public static class_3222 get(UUID uuid) {
        if (uuid == null) return null;
        MinecraftServer s = Battletower.server();
        if (s == null) return null;
        class_3222 p = s.method_3760().method_14602(uuid);
        if (p != null) return p;
        return TEST_PLAYERS.get(uuid);
    }

    public static class_3222 get(String uuid) {
        if (uuid == null) return null;
        try {
            return get(UUID.fromString(uuid));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public static boolean online(UUID uuid) {
        return get(uuid) != null;
    }

    public static void registerTest(class_3222 p) {
        TEST_PLAYERS.put(p.method_5667(), p);
    }

    public static void unregisterTest(UUID uuid) {
        TEST_PLAYERS.remove(uuid);
    }

    public static boolean isTest(UUID uuid) {
        return TEST_PLAYERS.containsKey(uuid);
    }
}
