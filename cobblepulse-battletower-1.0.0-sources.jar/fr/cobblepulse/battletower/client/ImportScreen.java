package fr.cobblepulse.battletower.client;

import fr.cobblepulse.battletower.data.ShowdownFormat;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7529;

/** Collage d'une equipe au format texte de Pokemon Showdown. */
final class ImportScreen extends class_437 {
    private final TrainerEditorScreen parent;
    private class_7529 area;

    ImportScreen(TrainerEditorScreen parent) {
        super(class_2561.method_43470("Importer une équipe Showdown"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int w = Math.min(field_22789 - 20, 420);
        int h = Math.min(field_22790 - 70, 220);
        int x = (field_22789 - w) / 2;
        int y = 30;
        area = new class_7529(field_22793, x, y, w, h, class_2561.method_43470("Collez ici l'export du teambuilder (Ctrl+V)"), class_2561.method_43473());
        area.method_44402(20000);
        method_37063(area);
        method_37063(class_4185.method_46430(class_2561.method_43470("Importer"), b -> {
            parent.importTeam(ShowdownFormat.parse(area.method_44405()));
            field_22787.method_1507(parent);
        }).method_46434(x + w - 180, y + h + 8, 86, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"), b -> field_22787.method_1507(parent)).method_46434(x + w - 90, y + h + 8, 90, 20).method_46431());
        method_48265(area);
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTick) {
        super.method_25394(g, mouseX, mouseY, partialTick);
        g.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFE0B040);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
