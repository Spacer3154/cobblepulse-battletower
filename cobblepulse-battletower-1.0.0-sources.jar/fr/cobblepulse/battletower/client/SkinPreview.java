package fr.cobblepulse.battletower.client;

import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_765;
import net.minecraft.class_7833;

/** Rendu 3D d'un skin (modele joueur classique ou fin) dans une interface, orientable a la souris. */
public final class SkinPreview {
    private static class_591<class_1309> wide;
    private static class_591<class_1309> slim;

    private SkinPreview() {}

    private static class_591<class_1309> model(boolean slimArms) {
        class_310 mc = class_310.method_1551();
        if (slimArms) {
            if (slim == null) slim = new class_591<>(mc.method_31974().method_32072(class_5602.field_27581), true);
            return slim;
        }
        if (wide == null) wide = new class_591<>(mc.method_31974().method_32072(class_5602.field_27577), false);
        return wide;
    }

    /**
     * @param feetX  centre horizontal
     * @param feetY  position des pieds
     * @param size   hauteur d'un bloc en pixels d'interface (le modele mesure 2 blocs)
     * @param yaw    rotation en degres
     */
    public static void render(class_332 g, SkinCache.Skin skin, int feetX, int feetY, float size, float yaw, float pitch) {
        if (skin == null) return;
        class_591<class_1309> m = model(skin.slim());
        m.field_3448 = false;
        m.field_3400 = false;
        class_4587 ps = g.method_51448();
        ps.method_22903();
        ps.method_46416(feetX, feetY, 150);
        ps.method_22905(size, size, -size);
        ps.method_46416(0, -1.501f, 0);
        ps.method_22907(class_7833.field_40714.rotationDegrees(-pitch));
        ps.method_22907(class_7833.field_40716.rotationDegrees(yaw));
        class_308.method_34742();
        var buffer = g.method_51450().getBuffer(class_1921.method_23580(skin.texture()));
        m.method_2828(ps, buffer, class_765.field_32767, class_4608.field_21444, 0xFFFFFFFF);
        g.method_51452();
        class_308.method_24211();
        ps.method_22909();
    }
}
