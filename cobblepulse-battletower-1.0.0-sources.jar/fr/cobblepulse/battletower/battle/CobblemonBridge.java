package fr.cobblepulse.battletower.battle;

import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.battles.model.PokemonBattle;
import com.cobblemon.mod.common.api.moves.Move;
import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.api.types.ElementalType;
import com.cobblemon.mod.common.battles.BattleRegistry;
import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokemon.FormData;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.pokemon.Species;
import fr.cobblepulse.battletower.Battletower;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Acces a l'API Cobblemon : equipes, PC, combats en cours. */
public final class CobblemonBridge {
    /** Resume d'un Pokemon (validation des tiers). */
    /**
     * @param aliases autres identifiants de l'espece (chemin et identifiant complet normalises) : un tier peut bannir un
     *                fakemon par son nom ({@code voltmon}) comme par son identifiant ({@code monpack:volt_mon}).
     */
    public record MonInfo(String species, String speciesId, String formId, int level, String heldItem, String ability,
                          List<String> moves, Set<String> types, boolean hasPreEvolution, boolean canEvolve, boolean shiny,
                          Set<String> aliases) {}

    private CobblemonBridge() {}

    public static PlayerPartyStore party(class_3222 p) {
        return Cobblemon.INSTANCE.getStorage().getParty(p);
    }

    public static List<Pokemon> partyList(class_3222 p) {
        List<Pokemon> out = new ArrayList<>();
        for (Pokemon pk : party(p)) if (pk != null) out.add(pk);
        return out;
    }

    public static void heal(class_3222 p) {
        try {
            party(p).heal();
        } catch (Throwable t) {
            Battletower.LOG.warn("[Battletower] Soin de l'equipe impossible : {}", t.toString());
        }
    }

    public static boolean isInBattle(class_3222 p) {
        try {
            return BattleRegistry.getBattleByParticipatingPlayer(p) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public static PokemonBattle battle(UUID id) {
        return id == null ? null : BattleRegistry.getBattle(id);
    }

    public static boolean battleActive(UUID id) {
        PokemonBattle b = battle(id);
        return b != null && !b.getEnded();
    }

    public static void stopBattle(UUID id) {
        try {
            PokemonBattle b = battle(id);
            if (b != null && !b.getEnded()) b.stop();
        } catch (Throwable t) {
            Battletower.LOG.warn("[Battletower] Arret du combat {} impossible : {}", id, t.toString());
        }
    }

    /** Victoire forcee d'un cote (auto-test) : "p1" ou "p2". */
    public static void forceWin(UUID id, String side) {
        PokemonBattle b = battle(id);
        if (b != null) b.writeShowdownAction(">forcewin " + side);
    }

    /** Ouvre le PC du joueur a distance (commande /pc de Cobblemon executee pour lui). */
    public static boolean openPc(class_3222 p) {
        MinecraftServer s = p.field_13995;
        try {
            s.method_3734().method_44252(p.method_5671().method_9206(4).method_9217(), "pc");
            return true;
        } catch (Throwable t) {
            Battletower.LOG.warn("[Battletower] Ouverture du PC impossible : {}", t.toString());
            return false;
        }
    }

    public static List<MonInfo> teamInfo(class_3222 p) {
        List<MonInfo> out = new ArrayList<>();
        for (Pokemon pk : partyList(p)) out.add(info(pk));
        return out;
    }

    public static MonInfo info(Pokemon pk) {
        Species sp = pk.getSpecies();
        FormData form = pk.getForm();
        String speciesId = norm(sp.getName());
        String formName = form == null ? "" : form.getName();
        String formId = formName == null || formName.isEmpty() || formName.equalsIgnoreCase("normal") ? speciesId : norm(sp.getName() + formName);
        class_1799 held = pk.heldItem();
        String heldId = held == null || held.method_7960() ? "" : class_7923.field_41178.method_10221(held.method_7909()).toString();
        String ability = "";
        try {
            ability = pk.getAbility().getName();
        } catch (Throwable ignored) {
        }
        List<String> moves = new ArrayList<>();
        try {
            for (Move m : pk.getMoveSet().getMoves()) moves.add(m.getName());
        } catch (Throwable ignored) {
        }
        Set<String> types = new LinkedHashSet<>();
        for (ElementalType t : pk.getTypes()) types.add(t.getName().toLowerCase(Locale.ROOT));
        boolean pre = false;
        boolean evo = false;
        try {
            pre = form != null && form.getPreEvolution() != null;
            evo = form != null && !form.getEvolutions().isEmpty();
        } catch (Throwable ignored) {
        }
        Set<String> aliases = new LinkedHashSet<>();
        try {
            aliases.add(norm(sp.getResourceIdentifier().method_12832()));
            aliases.add(norm(sp.getResourceIdentifier().toString()));
        } catch (Throwable ignored) {
        }
        return new MonInfo(sp.getName(), speciesId, formId, pk.getLevel(), heldId, ability, moves, types, pre, evo, pk.getShiny(), aliases);
    }

    /** L'equipe est-elle Monotype (au moins un type commun) ? */
    public static boolean monotype(class_3222 p) {
        Set<String> shared = null;
        for (MonInfo m : teamInfo(p)) {
            if (shared == null) shared = new LinkedHashSet<>(m.types());
            else shared.retainAll(m.types());
        }
        return shared != null && !shared.isEmpty();
    }

    public static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    public static class_1799 icon(Pokemon pk) {
        try {
            return PokemonItem.from(pk);
        } catch (Throwable t) {
            return new class_1799(class_1802.field_8803);
        }
    }

    public static class_1799 speciesIcon(String speciesName) {
        try {
            Species sp = SpeciesLookup.resolve(speciesName);
            if (sp != null) return PokemonItem.from(sp);
        } catch (Throwable ignored) {
        }
        return new class_1799(class_1802.field_8803);
    }

    /** Ajoute un Pokemon a l'equipe d'un joueur (auto-test). */
    public static void givePokemon(class_3222 p, String properties) {
        Pokemon pk = PokemonProperties.Companion.parse(properties).create();
        party(p).add(pk);
    }
}
